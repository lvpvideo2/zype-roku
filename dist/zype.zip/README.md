<h1>Zype Roku</h1>
This is the MVP for a Zype video player.

<h2>Screens</h2>
<h3>Home</h3>
<h3>Details</h3>
<h3>Search</h3>
<h3>Search Results</h3>
<h3>Info</h3>

<h2>To do:</h2>
<ul>
  <li>advertising</li>
  <li>suggested search</li>
  <li>save playback position</li>
  <li>improve search results metadata</li>
  <li>zobject visualization</li>
  <li>this readme</li>
  <li>comment code  'who comments?</li>
  <li>load config via api call</li>
  <li>remove config from m?</li>
</ul>