<h1>Zype Roku</h1>
This is the MVP for a Zype video player.

<h2>Screens</h2>
<h3>Home</h3>
<h3>Detail</h3>
<h3>Search</h3>
<h3>Search Results</h3>
<h3>Info</h3>
<h3>Player</h3>

<h2>Development Setup</h2>
<p>Configure app.mk with the local ip address and password of your device.</p>

<h2>To do:</h2>
<ul>
  <li>advertising</li>
  <li>suggested search</li>
  <li>save playback position</li>
  <li>improve search results metadata</li>
  <li>zobject visualization</li>
  <li>this readme</li>
  <li>comment code  'who comments?</li>
  <li>remove config from m?</li>
  <li>theme asset parsing assumes .png</li>
  <li>disable any print/debug output</li>
</ul>